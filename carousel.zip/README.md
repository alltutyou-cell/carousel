# Carousel Editor

AI-assisted Instagram carousel editor — paste text, drop in photos and videos, the AI splits and matches, you edit visually, export PNG/MP4.

## Что внутри

- **Next.js 14** (App Router) — деплой на Vercel в 2 клика
- **AI-сплит текста** через Claude API (server-side, ключ защищён)
- **AI-подбор фото** к каждому слайду через vision (тоже server-side)
- **Видео-фон** с автоматической обрезкой до 10 сек и форматом 4:5 (через `ffmpeg.wasm` в браузере)
- **Drag/resize** текста, **inline-редактирование**, **drag-reorder** слайдов
- Экспорт: **PNG** для фото-слайдов, **MP4** для видео-слайдов с baked-in текстом

---

## Шаг 1 — Поставить локально (опционально, для проверки)

```bash
npm install
cp .env.example .env.local
# Открой .env.local и впиши свой ключ из https://console.anthropic.com/
npm run dev
```

Откроется на `http://localhost:3000`.

---

## Шаг 2 — Залить на GitHub

```bash
git init
git add .
git commit -m "Initial carousel editor"
gh repo create carousel-editor --private --source=. --push
# Если нет gh CLI — создай репо на github.com вручную и сделай git push.
```

---

## Шаг 3 — Деплой на Vercel

1. Зайди на [vercel.com](https://vercel.com), залогинься через GitHub
2. **New Project** → выбери репо `carousel-editor`
3. Framework: **Next.js** определится автоматически
4. **Environment Variables** — добавь:
   - Name: `ANTHROPIC_API_KEY`
   - Value: твой ключ (`sk-ant-...`)
5. **Deploy**

Через ~2 минуты получишь URL: `https://carousel-editor-xxx.vercel.app`

При следующем `git push` Vercel автоматически передеплоит.

---

## Архитектура

```
app/
  page.tsx                   ← главный UI (Setup + Editor views)
  layout.tsx                 ← root layout
  globals.css                ← стили + шрифты
  api/
    ai-split/route.js        ← разбивает текст на слайды через Claude
    ai-match-photos/route.js ← подбирает фото к слайду через vision
lib/
  video.js                   ← клиентский ffmpeg.wasm (trim, crop, thumbnail)
next.config.js               ← заголовки COOP/COEP для ffmpeg.wasm
```

### Поток данных

1. **Setup view**: ты вставляешь текст и медиа
2. При загрузке видео — `ffmpeg.wasm` обрезает до 10s + до 1080×1350 в браузере
3. По клику «Создать карусель»:
   - Сжимаем фото до 800px и шлём на `/api/ai-split` + `/api/ai-match-photos`
   - Бэкенд вызывает Claude API с server-side ключом
   - Получаем массив слайдов и присвоения
4. **Editor view**: рендеришь, двигаешь текст, экспортишь
5. PNG-экспорт — через `html2canvas`
6. MP4-экспорт — `html2canvas` рендерит текст в прозрачный PNG, `ffmpeg.wasm` накладывает PNG поверх видео

---

## Дальше (Этап 2 — стили)

Когда дашь референсы карусельных стилей, добавим переключатель пресетов:
- Текущий: serif headline + mono caption (тёмный градиент снизу)
- Maximalist (большие цветные плашки)
- Editorial (магазинная вёрстка)
- Минимал (одна линия серого текста)

Стили будут жить в `lib/styles.js` как набор шаблонов textBox-конфигов.

---

## Известные ограничения

- Видео экспорт работает только в десктопных браузерах (Chrome, Edge, Firefox). Safari может тормозить из-за SharedArrayBuffer
- Большие видео (>200MB) обрабатываются медленно из-за WASM
- Vercel free tier имеет лимит execution на serverless — но AI-сплит укладывается в 30 сек
- Длина видео в карусели Instagram максимум 60 сек (приложение режет до 10 — можешь поменять `maxDuration` в `app/page.tsx`)

---

## Полезные ссылки

- [Anthropic Console](https://console.anthropic.com/) — взять API ключ
- [Vercel Dashboard](https://vercel.com/dashboard) — управление проектом
- [ffmpeg.wasm docs](https://ffmpegwasm.netlify.app/) — кастомизация видео-обработки
